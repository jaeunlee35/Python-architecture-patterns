import logging

# Generate two logs with different severity levels
logging.warning('This is a warning message')
logging.info('This is an info message')
