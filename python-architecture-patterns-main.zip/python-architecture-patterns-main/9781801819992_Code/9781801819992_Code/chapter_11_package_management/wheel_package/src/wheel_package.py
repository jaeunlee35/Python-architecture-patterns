from submodule.submodule import subfunction


def some_function():
    result = subfunction()
    return f'some function {result}'
