from .module import some_function
