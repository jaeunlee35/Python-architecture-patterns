def subfunction():
    return 'calling subfunction'
