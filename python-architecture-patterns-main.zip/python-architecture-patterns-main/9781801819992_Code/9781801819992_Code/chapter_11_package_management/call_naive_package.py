from naive_package import some_function


print(some_function())
