from celery_tasks import obtain_info


obtain_info.delay()
